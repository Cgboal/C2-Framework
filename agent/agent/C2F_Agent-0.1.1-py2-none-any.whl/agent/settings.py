import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

state_file = BASE_DIR + "/agent/state.p"

settings_file_path = BASE_DIR + '/agent/settings.py'

commands = ['c2d']